﻿namespace WebApplicationFinal.Models
{
    public class MysqlClass
    {
        public string ID_admin { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public string Name { get; set; }
        public string Pass { get; set; }

        public string Location { get; set; }
        public string Email { get; set; }
        public string Full_Name { get; set; }
        public string Phone_NR { get; set; }

    }
}